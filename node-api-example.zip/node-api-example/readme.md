mynode.sql是数据库备份，请创建你的数据库，并导入此备份。

apiserv.js是接口服务文件，需要你配置自己的数据库。

pageserv.js 是页面服务。

view/backend目录中的add.html和edit.html是从之前PHP的项目中复制过来的，进行了简单修改。
理解逻辑即可，实际开发过程中使用更加专业的前端工具。

